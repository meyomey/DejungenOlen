# -*- coding: utf-8 -*-
"""Build 2026-11-07 ay – „Als GPX speichern": bei Mitgliedern blieb die Tour ohne Track.

Der Nutzer: „Checke die Funktion ‚Als GPX speichern'. Irgendwie wird bei mir anschließend kein
Track angezeigt." Nachgefragt: Knopf auf der Live-Karte nach „Fahrt beenden", kurze Fahrt mit
dem Handy, Datei in Ordnung – aber auf der Tourseite kein Track.

Gemessen (Mitglied, 45 Punkte, 1,9 km):
  Ausgangslage                    gpx_file=None      → Tourseite GPX_DATA=null, 0 Linien
  Mitglied lädt GPX herunter      gpx_file=None      → Tour bleibt ohne Track
  Übernehmen-Knopf für Mitglied   nicht vorhanden
  Nach dem Fix: Mitglied klickt „Meine Aufzeichnung als Track übernehmen"
                                  gpx_file=…, 1,9 km → Tourseite 2 Linien, 45 Punkte, Zoom 14
"""
import os
import re
import unittest

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


def _read(*pfad):
    with open(os.path.join(ROOT, *pfad), encoding='utf-8') as f:
        return f.read()


class MitgliedDarfUebernehmenTest(unittest.TestCase):
    """Die Route darf jetzt auch ein Mitglied – aber nur für die EIGENE Aufzeichnung."""

    def test_route_erlaubt_eigene_aufzeichnung(self):
        app_py = _read('app.py')
        block = app_py.split("def tour_live_recording(tour_id):", 1)[1].split('\n@app.route', 1)[0]
        # Der alte Pauschal-Riegel (jeder Nicht-Manager -> 403) ist weg
        self.assertNotIn("    if not _can_manage_tour(tour):\n        abort(403)\n    summaries", block)
        # … und durch die Prüfung auf die eigene Aufzeichnung ersetzt
        self.assertIn("if not summary or summary['user_id'] != current_user.id:", block)
        self.assertIn('abort(403)', block)

    def test_fremde_aufzeichnung_bleibt_gesperrt(self):
        app_py = _read('app.py')
        block = app_py.split("def tour_live_recording(tour_id):", 1)[1].split('\n@app.route', 1)[0]
        # fremde Aufzeichnung: uid != current_user -> 403
        self.assertIn("summary['user_id'] != current_user.id", block)

    def test_vorhandener_track_wird_nicht_von_mitgliedern_ersetzt(self):
        app_py = _read('app.py')
        block = app_py.split("def tour_live_recording(tour_id):", 1)[1].split('\n@app.route', 1)[0]
        self.assertIn('if tour.gpx_file:', block)
        self.assertIn('hat schon einen GPX-Track', block)


class KnopfAufDerTourseiteTest(unittest.TestCase):
    """Ein Mitglied sah auf der Tourseite GAR KEINEN Übernehmen-Knopf – nur die Orga."""

    def test_mitglied_sieht_uebernehmen_knopf(self):
        html = _read('templates', 'touren', 'detail.html')
        self.assertIn('{% if can_manage or (live_rec_mine and not tour.gpx_file) %}', html)
        self.assertIn('Meine Aufzeichnung als Track übernehmen', html)

    def test_mitglied_schickt_eigene_user_id(self):
        html = _read('templates', 'touren', 'detail.html')
        block = html.split('Meine Aufzeichnung als Track übernehmen', 1)[0]
        self.assertIn('<input type="hidden" name="user_id" value="{{ current_user.id }}">', block)

    def test_orga_sieht_weiter_die_auswahl(self):
        html = _read('templates', 'touren', 'detail.html')
        self.assertIn('Als GPX-Track der Tour übernehmen', html)
        self.assertIn('<select name="user_id"', html)


class LiveKarteUebernehmenTest(unittest.TestCase):
    """Auf der Live-Karte gab es für Mitglieder nur „⬇ GPX speichern" – die Datei landete auf
    dem Handy, die Tour blieb ohne Track. Jetzt steht dort „✓ Als Track übernehmen"."""

    def test_live_karte_hat_uebernehmen_knopf(self):
        html = _read('templates', 'touren', 'live.html')
        self.assertIn('✓ Als Track übernehmen', html)
        # das Formular um den Knopf herum (nicht der Kommentar davor)
        block = html.split('<form method="post" action="{{ url_for(\'tour_live_recording\'', 1)[1]
        block = block.split('</form>', 1)[0]
        self.assertIn('name="action" value="adopt"', block)
        self.assertIn('name="user_id" value="{{ current_user.id }}"', block)
        self.assertIn('✓ Als Track übernehmen', block)

    def test_download_daneben_bleibt(self):
        html = _read('templates', 'touren', 'live.html')
        # wer die Datei will, bekommt sie weiter – aber nicht mehr als einzige Möglichkeit
        self.assertIn('⬇ GPX speichern', html)

    def test_uebernehmen_ist_kein_link_sondern_ein_formular(self):
        html = _read('templates', 'touren', 'live.html')
        block = html.split('id="rec-hint"', 1)[1].split('</form>', 1)[0]
        # ein echtes POST-Formular – kein Link auf die Tourseite (dort landete man ohne Track)
        self.assertIn('method="post"', block)
        self.assertIn("url_for('tour_live_recording'", block)


class DownloadFehlerTest(unittest.TestCase):
    """Vorher: 404 lieferte die HTML-Fehlerseite – der Browser speicherte sie trotzdem als
    „…_live_….gpx". Der Nutzer hielt eine kaputte Datei in der Hand, ohne Hinweis."""

    def test_keine_html_datei_als_gpx(self):
        app_py = _read('app.py')
        block = app_py.split("def tour_live_recording_download(tour_id):", 1)[1].split('\n@app.route', 1)[0]
        self.assertNotIn('abort(404)', block)
        self.assertIn('keine brauchbare Aufzeichnung', block)
        self.assertIn('flash(', block)

    def test_meldung_nennt_die_ursache(self):
        app_py = _read('app.py')
        block = app_py.split("def tour_live_recording_download(tour_id):", 1)[1].split('\n@app.route', 1)[0]
        # die zwei echten Ursachen: zu wenige Punkte, zu ungenaues GPS
        self.assertIn('mindestens 8 Punkte', block)
        self.assertIn('WLAN-Ortung', block)


if __name__ == '__main__':
    unittest.main()

class AuchAdminBrauchtEinenEchtenKnopfTest(unittest.TestCase):
    """Build ay, Nachtrag: „Ich hatte das vorher als Admin gemacht, nicht als Mitglied."

    Damit war die erste Erklärung unvollständig. Der Knopf, den ein ADMIN in Build ax sah,
    war ein LINK auf die Tourseite („✓ Als GPX übernehmen" -> /touren/1#live-aufzeichnung).
    Er hat nichts übernommen – er hat nur die Seite gewechselt. Die Strecke blieb weg, weil
    man auf der Tourseite noch einmal „Als GPX-Track der Tour übernehmen" drücken musste.

    Gemessen in Build ax (Admin, 45 Punkte, 1,9 km): nach dem Klick 0 Linien, GPX_DATA=null.
    Jetzt: ein POST-Formular, das direkt übernimmt – 2 Linien, 45 Punkte, Meldung sichtbar.
    """

    def test_uebernehmen_postet_direkt_statt_zu_verlinken(self):
        html = _read('templates', 'touren', 'live.html')
        block = html.split('id="rec-hint"', 1)[1].split('</form>', 1)[0]
        self.assertIn('<form method="post"', block)
        self.assertIn('name="action" value="adopt"', block)
        # der alte, folgenlose Link darf dort nicht mehr stehen
        self.assertNotIn("href=\"{{ url_for('tour_detail', tour_id=tour.id) }}#live-aufzeichnung\"", block)

    def test_admin_und_mitglied_bekommen_denselben_knopf(self):
        """Kein Unterschied mehr zwischen den Rollen – beide uebernehmen mit einem Klick."""
        html = _read('templates', 'touren', 'live.html')
        block = html.split('id="rec-hint"', 1)[1].split('</form>', 1)[0]
        self.assertNotIn('{% if can_takeover %}', block)
        self.assertIn('✓ Als Track übernehmen', block)

    def test_kein_link_ohne_wirkung_mehr_im_status(self):
        """Auch die Statusmeldung nach dem Beenden schickte nur auf die Tourseite."""
        html = _read('templates', 'touren', 'live.html')
        # der Status darf weiter auf die Tourseite hinweisen (dort steht die Aufzeichnung),
        # aber der KNOPF im Hinweis muss uebernehmen
        block = html.split('id="rec-hint"', 1)[1].split('</form>', 1)[0]
        self.assertIn('type="submit"', block)


if __name__ == "__main__":
    unittest.main()

class HinweisAuchImVollbildTest(unittest.TestCase):
    """Build ba: „Wenn in der Live Karte die große Kartendarstellung aktiv ist und die Fahrt
    beendet sieht man keinen Hinweis auf Track/GPX speichern."

    Der Hinweis stand AUSSERHALB von #live-wrap. Im Vollbild ist das aber
    `position: fixed; inset: 0` mit z-index 2000 und deckte ihn komplett ab.
    Gemessen vorher: `elementFromPoint` an der Stelle des Hinweises ergab „live-map",
    beide Knoepfe „nicht sichtbar". Jetzt gibt es eine zweite Kopie INNERHALB der Karte.
    Gemessen nachher: im Vollbild sichtbar und klickbar, ausserhalb unsichtbar – nie beide.
    """

    def test_zweite_kopie_liegt_in_der_karte(self):
        html = _read('templates', 'touren', 'live.html')
        i_wrap = html.find('<div id="live-wrap">')
        i_hint = html.find('id="rec-hint-fs"')
        i_end = html.find('id="live-bar"')
        self.assertGreater(i_wrap, 0)
        self.assertGreater(i_hint, i_wrap, 'Vollbild-Hinweis liegt nicht in #live-wrap')
        self.assertLess(i_hint, i_end)

    def test_kopie_hat_track_und_gpx_knopf(self):
        html = _read('templates', 'touren', 'live.html')
        block = html.split('id="rec-hint-fs"', 1)[1].split('</div>\n      </div>', 1)[0]
        self.assertIn('✓ Als Track übernehmen', block)
        self.assertIn('⬇ GPX speichern', block)
        self.assertIn('name="action" value="adopt"', block)

    def test_beide_kopien_werden_zusammen_geschaltet(self):
        html = _read('templates', 'touren', 'live.html')
        show = html.split('function showRecHint()', 1)[1].split('\nfunction ', 1)[0]
        hide = html.split('function hideRecHint()', 1)[1].split('\nfunction ', 1)[0]
        self.assertIn("getElementById('rec-hint-fs')", show)
        self.assertIn("getElementById('rec-hint-fs')", hide)

    def test_kein_scrollen_im_vollbild(self):
        """Im Vollbild waere scrollIntoView sinnlos – die Karte deckt alles ab."""
        html = _read('templates', 'touren', 'live.html')
        show = html.split('function showRecHint()', 1)[1].split('\nfunction ', 1)[0]
        self.assertIn('if (_fsAn()) return;', show)

    def test_hinweis_weicht_der_symbolspalte_rechts(self):
        """Gemessen: mit right:8px lag die Symbolspalte auf dem dritten Knopf."""
        html = _read('templates', 'touren', 'live.html')
        block = html.split('id="rec-hint-fs"', 1)[1].split('>', 1)[0]
        self.assertIn('right: 56px', block)


if __name__ == "__main__":
    unittest.main()

class VollbildKnoepfeWeiterUntenTest(unittest.TestCase):
    """Build bb: „Könnte man die Symbole und Knöpfe bei der Vollkarte weiter nach unten bringen?"

    Im Vollbild liegt die Karte über der unteren App-Navigation. Gemessen: bottom-nav
    NICHT sichtbar, `navUnten = 0` – trotzdem hielten Knopfleiste, Statuszeile, Pill und 🔒
    die 58 px für sie frei. Unter der Leiste blieb ein leerer Streifen von 58 px.

    Nach dem Umbau gemessen (460×900, Vollbild):
      Leiste     unten 0    (vorher 58)
      Status     unten 64   (vorher 122)
      Symbolspalte über der Statuszeile, keine Überlappung (vorher stieß sie an die Leiste)
    """

    def test_leiste_geht_im_vollbild_an_den_rand(self):
        html = _read('templates', 'touren', 'live.html')
        self.assertIn('#live-wrap.live-fs #live-bar { bottom: 0;', html)

    def test_statuszeile_und_pill_ruecken_mit(self):
        html = _read('templates', 'touren', 'live.html')
        self.assertIn('#live-wrap.live-fs #live-status { bottom: 64px; }', html)
        self.assertIn('#live-wrap.live-fs #live-guard-pill,\n    #live-wrap.live-fs #live-guard-lock', html)

    def test_symbolspalte_ueber_der_statuszeile(self):
        """5 Knöpfe à 42 px = 234 px. Ganz unten traf sie die Knopfleiste (gemessen)."""
        html = _read('templates', 'touren', 'live.html')
        block = html.split('#live-wrap.live-fs #live-tools {', 1)[1].split('}', 1)[0]
        self.assertIn('bottom: calc(64px + 3.1em + 8px)', block)

    def test_vollbild_hinweis_rueckt_mit(self):
        html = _read('templates', 'touren', 'live.html')
        self.assertIn('#live-wrap.live-fs #rec-hint-fs { bottom: 64px; }', html)

    def test_normalbetrieb_bleibt_unveraendert(self):
        """Ausserhalb des Vollbilds liegt die App-Navigation unten – dort bleiben die 58 px."""
        html = _read('templates', 'touren', 'live.html')
        self.assertIn('bottom: calc(58px + env(safe-area-inset-bottom));', html)
        self.assertIn('#live-status { position: fixed; left: 8px; bottom: calc(58px + 64px);', html)


if __name__ == "__main__":
    unittest.main()
